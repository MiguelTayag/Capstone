// games.js

const games = [
  {
    title: "The Legend of Zelda: Breath of the Wild",
    platform: "Nintendo Switch",
    releaseYear: 2017,
    image: "assets/images/zelda.jpg",
  },
  {
    title: "Red Dead Redemption 2",
    platform: "PlayStation 4, Xbox One",
    releaseYear: 2018,
    image: "assets/images/red-dead.jpg",
  },
  {
    title: "Cyberpunk 2077",
    platform: "PlayStation 5, Xbox Series X/S, PC",
    releaseYear: 2020,
    image: "assets/images/cyberpunk.jpg",
  },
  // Add more game data as needed
];

const gameList = document.getElementById("gameList");

games.forEach((game) => {
  const card = document.createElement("div");
  card.classList.add("col-md-4", "mb-4");

  card.innerHTML = `
        <div class="card">
            <img src="${game.image}" class="card-img-top" alt="${game.title}">
            <div class="card-body">
                <h5 class="card-title">${game.title}</h5>
                <p class="card-text">Platform: ${game.platform}</p>
                <p class="card-text">Release Year: ${game.releaseYear}</p>
            </div>
        </div>
    `;

  gameList.appendChild(card);
});
