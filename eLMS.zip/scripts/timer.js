// timer.js

//--- Timer for index -----//
let seconds = 0;
const timerElement = document.getElementById("timer");

function updateTimer() {
  seconds++;
  timerElement.textContent = seconds + " seconds";
}

setInterval(updateTimer, 1000); // Update the timer every second

//----- Timer for studentTime ------//

const studentForm = document.getElementById("studentForm");
const timer1Element = document.getElementById("timer1");
const timer2Element = document.getElementById("timer2");
const timer3Element = document.getElementById("timer3");

let timer1 = 0;
let timer2 = 0;
let timer3 = 0;

studentForm.addEventListener("submit", function (e) {
  e.preventDefault();

  // Get the values from the input fields
  const student1Name = document.getElementById("student1").value.trim();
  const student2Name = document.getElementById("student2").value.trim();
  const student3Name = document.getElementById("student3").value.trim();

  // Start the timers only if the input fields are not empty
  if (student1Name !== "") {
    startTimer(timer1Element, timer1);
  }

  if (student2Name !== "") {
    startTimer(timer2Element, timer2);
  }

  if (student3Name !== "") {
    startTimer(timer3Element, timer3);
  }
});

function startTimer(timerElement, timer) {
  setInterval(function () {
    timer++;
    timerElement.textContent = timer + " seconds";
  }, 1000);
}
