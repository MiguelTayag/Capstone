// const fetch = require("node-fetch");
const express = require("express");
const fs = require("fs");
const readline = require("readline");
const path = require("path");
// var bodyParser = require('body-parser')
const app = express();
const mysql = require("mysql");
const pool = dbConnection();
app.use(express.urlencoded({ extended: true }));

// Function to read logs from the TXT file
function readLogsFromFile(filePath) {
  const logs = [];
  const fileStream = fs.createReadStream(filePath);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity,
  });

  rl.on("line", (line) => {
    const [timestamp, ...messageParts] = line.split(" ");
    const message = messageParts.join(" ");
    logs.push({ timestamp, message });
  });

  return logs;
}

// Specify the path to the logs file
const logsFilePath = "testInput/process.txt";

// Read logs from the file
const logs = readLogsFromFile(logsFilePath);

// create application/x-www-form-urlencoded parser
// var urlencodedParser = bodyParser.urlencoded({ extended: false })
app.set("view engine", "ejs");

//include public folder
app.use(express.static("public"));

app.get("/", async (req, res) => {
  let sql = `SELECT *
               FROM s_logs`;
  let rows = await executeSQL(sql);
  console.log(rows);
  res.render("home", { rows: "rows" });
});

// Work in progress: processes logs
app.get("/processLogs", async (req, res) => {
  res.render("processLogs", { logs });
});

app.get("/computerTimers", async (req, res) => {
  console.log("rendering computerTimers");
  let sql = `SELECT *
               FROM c_status`;
  let computerStatus = await executeSQL(sql);
  var currentdate = new Date();
  var datetime =
    "" +
    currentdate.getFullYear() +
    "-" +
    (currentdate.getMonth() + 1) +
    "-" +
    currentdate.getDate() +
    " " +
    ("0" + (currentdate.getUTCHours() + 17)).slice(-2) +
    ":" +
    ("0" + currentdate.getMinutes()).slice(-2) +
    ":" +
    ("0" + currentdate.getSeconds()).slice(-2);
  res.render("computerTimers", {
    computerStatus: computerStatus,
    currentdate: currentdate,
  });
});

// app.get("/studentTimers", async (req, res) => {
//     res.render("studentTimers", { computerStatus: computerStatus });
// });

app.get("/timerLogs", async (req, res) => {
  let sql = "SELECT * FROM s_logs ORDER BY s_date DESC";
  let params = req.query.s_id;
  let rows = await executeSQL(sql, params);
  console.log("rendering timerLogs");
  res.render("timerLogs", { rows: rows });
});

app.get("/games", async (req, res) => {
  let sql = `SELECT *
               FROM p_games`;
  let gameRows = await executeSQL(sql);
  console.log("rendering games");
  res.render("games", { gameRows: gameRows });
});

// Specify the path to the PDF file
const pdfFilePath = path.join(
  __dirname,
  "public",
  "images",
  "documentation.pdf",
);
app.set("views", path.join(__dirname, "views"));

app.get("/documentation", (req, res) => {
  console.log("rendering");
  res.render("documentation", { pdfFilePath });
});

app.get("/about", (req, res) => {
  console.log("rendering");
  res.render("about");
});

app.post("/studentTimers", async (req, res) => {
  let id = req.body.studentId;
  let name = req.body.studentName;
  let computer = req.body.computerNumber;
  let email = req.body.studentEmail + "@csumb.edu";
  var currentdate = new Date();
  var datetime =
    "" +
    currentdate.getFullYear() +
    "-" +
    (currentdate.getMonth() + 1) +
    "-" +
    currentdate.getDate() +
    " " +
    ("0" + (currentdate.getUTCHours() + 17)).slice(-2) +
    ":" +
    ("0" + currentdate.getMinutes()).slice(-2) +
    ":" +
    ("0" + currentdate.getSeconds()).slice(-2);
  console.log(name + "\n" + computer + "\n" + email + "\n" + datetime);

  let sql = `INSERT INTO s_logs 
            (s_id, s_name, s_comp, s_email, s_date)
            VALUES (?,?,?,?,?)`;
  let statusSql = `UPDATE c_status SET in_use = 1, time = ? WHERE c_number = ?`;
  let params = [id, name, computer, email, currentdate];
  let params2 = [currentdate, computer];
  let rows = await executeSQL(sql, params);
  let statusRows = await executeSQL(statusSql, params2);
  res.redirect("computerTimers");
});

app.post("/computerTimers", async (req, res) => {
  let computerId = req.body.computerId;
  let statusSql = "SELECT in_use FROM c_status WHERE c_number = ?";
  let statusRows = await executeSQL(statusSql, computerId);
  let status = statusRows[0].in_use;
  console.log(status);
  if (status == 0) {
    console.log("rendering studentTimers");
    res.render("studentTimers", { computerId: computerId });
  } else if (status == 1) {
    console.log("here");
    let sql = `UPDATE c_status SET in_use = 0, time = '0000-00-00 00:00:00' WHERE c_number = ?`;
    let rows = await executeSQL(sql, computerId);
    console.log("rendering computerTimers");
    res.redirect("computerTimers");
  }
});

// --------------- DB CONNECTION ---------------
// app.get("/dbTest", async function(req, res) {
//     let sql = "SELECT *";
//     let rows = await executeSQL(sql);
//     res.send(rows);
//     console.log("done");

// });//dbTest

async function executeSQL(sql, params) {
  return new Promise(function (resolve, reject) {
    pool.query(sql, params, function (err, rows, fields) {
      if (err) throw err;
      resolve(rows);
    });
  });
}

function dbConnection() {
  const pool = mysql.createPool({
    connectionLimit: 10,
    host: "sql3.freesqldatabase.com",
    user: "sql3654997",
    password: "7suPDuBFbZ",
    database: "sql3654997",
  });
  return pool;
}

app.listen(3000, () => {
  console.log("server started");
});

// https://getbootstrap.com/docs/5.3/examples/cover/

// Host: sql3.freesqldatabase.com
// Database name: sql3654997
// Database user: sql3654997
// Database password: 7suPDuBFbZ
// Port number: 3306
